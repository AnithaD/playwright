const { Given, When, Then} = require("@cucumber/cucumber");
const fs = require('fs');
const path = require('path');
const Canvas_AccessPointToAllPage = require('../../pages/Canvas_AccessPointToAllPage');
const ScreenshotUtility = require('../../utility/ScreenshotUtility');
const {Jimp} = require("jimp");

// const fs = require('fs-extra');
//const { expect } = require('@playwright/test');

let Val_Canvas;
let Dy_Layer;
let xaxis;
let page_dp;
const clusters = [], groupedClusters = [];
let app_Mode;

   Given('I am on the canvas application',{timeout: 99999},async function () {
    app_Mode = this.applicationType;
    if (app_Mode === 'web') {      
          page_dp = this.page;
          Val_Canvas = new Canvas_AccessPointToAllPage(page_dp);          
          Dy_Layer = await Val_Canvas.getDynamic_LayerPage();
          await Dy_Layer.goTo();
          const screenshotUtility = new ScreenshotUtility(this); // Pass the World instance
          await screenshotUtility.takeScreenshot("screenshots","canvas_application", null, null, page_dp, this.attach.bind(this));
    }
    else if (app_Mode === 'desktop') {
            console.log('Desktop application launched via exec process.');
        }
         });
         
   Given('I clear the canvas',{timeout: 99999}, async () => {
    if (app_Mode === 'web') {  
        // Get canvas bounding box
        const canvasBoundingBox = await page_dp.locator('canvas').boundingBox();
        if (!canvasBoundingBox) {
            console.error("Canvas not found!");
            return;
        }
        const { x, y, width, height } = canvasBoundingBox;
        xaxis = {"x": canvasBoundingBox.x,
                "y": canvasBoundingBox.y,
                "width": canvasBoundingBox.width,
                "height": canvasBoundingBox.height,
        }
        
        // Take a screenshot of the canvas
        const canvasScreenshot = await page_dp.screenshot({
            clip: { x, y, width, height },
        });
        
        const image = await Jimp.read(canvasScreenshot);

        // Thresholds for detecting orange color (tune for accuracy)
        const isOrange = (r, g, b) => r > 200 && g > 100 && g < 170 && b < 100;

        // Scan the image for orange pixels
        image.scan(0,0,image.bitmap.width,image.bitmap.height,function (pxX, pxY, idx) {
            const r = this.bitmap.data[idx + 0];
            const g = this.bitmap.data[idx + 1];
            const b = this.bitmap.data[idx + 2];

            if (isOrange(r, g, b)) {
                clusters.push({ x: pxX, y: pxY });
            }}
            );
           const radius = 14; // Approximate radius for clustering
           for (const point of clusters) {
               let found = false;
               for (const cluster of groupedClusters) {
               const dist = Math.sqrt(
                   Math.pow(cluster.x - point.x, 2) + Math.pow(cluster.y - point.y, 2)
               );
               if (dist < radius) {
                   cluster.points.push(point);
                   cluster.x = (cluster.x + point.x) / 2;
                   cluster.y = (cluster.y + point.y) / 2;
                   found = true;
                   break;
               }
               }
               if (!found) {
               groupedClusters.push({ x: point.x, y: point.y, points: [point] });
               }
           }
        }
    
    else if (app_Mode === 'desktop') {
            console.log('Desktop application launched via exec process.');
        }
         });
    

   When('I load a canvas with multiple clusters',{timeout: 999999},  async function () {
    if (app_Mode === 'web') { 
        // Array to store screenshots paths
        const screenshotPaths = [];
        
           // Write code here that turns the phrase above into concrete actions
           for (let i = 0; i < groupedClusters.length; i++) {
                const cluster = groupedClusters[i];
                const clusterScreenX = xaxis.x + cluster.x;
                const clusterScreenY = xaxis.y + cluster.y;
    
                // Move the mouse to the cluster position
                await this.page.mouse.move(clusterScreenX, clusterScreenY);
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Take a screenshot of the highlighted cluster
                const screenshotUtility = new ScreenshotUtility(this); // Pass the World instance
                await screenshotUtility.takeScreenshot("screenshots","I load a canvas with multiple clusters", `Cluster_${i + 1}`, xaxis, page_dp, this.attach.bind(this));
                //console.log(`Captured screenshot for cluster ${i + 1}.`);
                
                // // Ensure the folder exists or create it
                // const fullFolderPath = path.resolve('screenshots');
                // const filePath = path.join(fullFolderPath,`Cluster_${i + 1}.png`);
                // screenshotPaths.push(filePath);
            }
        // for (const screen_Path of screenshotPaths) {
        //     const screenshot = fs.readFileSync(screen_Path);
        //     await screenshotUtility.world.attach(screenshot, 'image/png');
        //     console.log(`Screenshot attached: ${screen_Path}`);
        // }
    }
    
            else if (app_Mode === 'desktop') {
                    console.log('Desktop application launched via exec process.');
                }
                 });

   Then('the application should detect and highlight each cluster',{timeout: 999999}, async function () {
           // Write code here that turns the phrase above into concrete actions
           if (app_Mode === 'web') { 
            console.log('Desktop application launched via exec process.');
            }
    
        else if (app_Mode === 'desktop') {
                console.log('Desktop application launched via exec process.');
            }
             });






