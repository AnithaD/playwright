const { format } = require("prettier");

module.exports = {
  "default": {
  "formateOptions":{
    "snippetInterface": "async-await"
  },
  "timeout": Infinity,
  "require": [    
    "utility/world.js",
    "utility/hooks.js",
    "features/step-definitions/**/*.js"    
  ],
  "paths":[
    "canvas/**/*.feature"
  ],
  //"parallel": false,  
  //"globalTimeout": 600000,
  "publishQuite": true,
  "dryRun": false,  
  "format": [
    "json:reports/cucumber-report.json",
    "pretty" ,
    "summary",
    "progress-bar"
  ],
   
}
};