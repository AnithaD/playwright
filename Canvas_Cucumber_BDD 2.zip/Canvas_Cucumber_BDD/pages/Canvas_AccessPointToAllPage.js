const Canvas_VerifyDynamicLayer_Cluster = require('../pages/Canvas_VerifyDynamicLayer_Cluster');

class Canvas_AccessPointToAllPage {
constructor(page)
{   
    if (!page) {
        throw new Error('Page object is not defined. Ensure it is initialized in hooks.');
      }  
    
    this.page = page;
    this.Dynamic_LayerPage = new Canvas_VerifyDynamicLayer_Cluster(page);
}

getDynamic_LayerPage()
{
    return  this.Dynamic_LayerPage;
}

}
module.exports = Canvas_AccessPointToAllPage;
