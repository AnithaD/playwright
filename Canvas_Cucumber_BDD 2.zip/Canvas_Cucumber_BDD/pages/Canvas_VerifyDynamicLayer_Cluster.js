// const {Jimp} = require("jimp");

const config = require('../utility/config');
/*const withTimeout = (promise, timeout) => {
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Timeout reached')), timeout)
    );
    return Promise.race([promise, timeoutPromise]);
  }; */
class Canvas_VerifyDynamicLayer_Cluster {
    constructor(page)
    {   // Define locator inside the Page
        this.page = page;      
    }
     
    async goTo()
    {   
        let retries = 3;
        while (retries > 0) {
            try {
              await this.page.goto(config.baseURL);
              break; // Break the loop if successful
            } catch (error) {
              console.error(`Error navigating to ${"https://openlayers.org/en/latest/examples/icon-negative.html"}:`, error);
              retries--;
              if (retries === 0) {
                throw new Error('Failed to navigate after multiple attempts');
              }
            }
          } 
          
    }
    
    }          
module.exports = Canvas_VerifyDynamicLayer_Cluster;

