const globals = require('globals');
const js = require('@eslint/js');
 
module.exports = [
  {
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: 'commonjs',
      globals: {
        ...globals.node,
        ...globals.browser,
      },
    },
    linterOptions: {
      reportUnusedDisableDirectives: true,
    },
    files: ['**/*.js', '**/*.cjs'],
    ignores: ['node_modules/**', 'cucumber-report.html'],
    rules: {
      ...js.configs.recommended.rules,
      'no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
      'no-console': ['warn', { allow: ['warn', 'error'] }],
      'no-duplicate-imports': 'error',
      'no-template-curly-in-string': 'error',
      'block-scoped-var': 'error',
      'curly': ['error', 'all'],
      'eqeqeq': ['error', 'always'],
      'no-implicit-coercion': 'error',
      'no-implicit-globals': 'error',
      'no-return-await': 'error',
      'require-atomic-updates': 'error',
      //'camelcase': ['error', { properties: 'never' }],
      'consistent-return': 'error',
      'dot-notation': 'error',
      'no-var': 'error',
      'prefer-const': 'error',
      'prefer-template': 'error',
      'require-await': 'error',
    },
  },
  {
    files: ['**/*.js'],
    rules: {
      'no-unused-vars': 'off',
      'require-await': 'off',
    },
  },
];