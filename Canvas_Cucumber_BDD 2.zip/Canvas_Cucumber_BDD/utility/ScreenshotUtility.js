const fs = require('fs');
const path = require('path');


class ScreenshotUtility {
    constructor(world) {
        this.world = world; // Store the World instance
    }


    
    async takeScreenshot(folderPath = 'screenshots', filePrefix = 'screenshot',filename = null, data = null, page,attach) {
        try {
            let screenshotBuffer;

            // Destructure properties from the options object
            data = data ?? { key: 'default' };
            
            // Ensure the folder exists or create it
            const fullFolderPath = path.resolve(folderPath);
            if (!fs.existsSync(fullFolderPath)) {
                fs.mkdirSync(fullFolderPath, { recursive: true });
            }

             // Generate a unique identifier and dynamic filename
            const uniqueIdentifier = Math.floor(Math.random() * 10000);
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            filename = filename || `${filePrefix}-${timestamp}-${uniqueIdentifier}`;         
            
            const filePath = path.join(fullFolderPath, `${filename}.png`);
             
            if(!data || data.key === 'default'){
            // Take the screenshot
           await page.screenshot({ path: filePath,fullPage: true });
            
            }else{
                await page.screenshot({path: filePath, fullPage: false, clip : {
                    x: data.x,
                    y: data.y,
                    width: data.width,
                    height: data.height,
                } });
            }

            
            await attach(fs.readFileSync(filePath), 'image/png', `${filename}`);
           
            
        } catch (error) {
            console.error('Failed to take screenshot:', error);
        }
    }


    async readAlltakenScreenshot() {
            // Ensure the folder exists or create it
            const fullFolderPath = path.resolve('screenshots');
            const filename = '\\Dynamic_Cluster\\';
            const screenshotDir = path.join(fullFolderPath, filename);
                // Read all screenshots from the directory
                const screenshots = fs.readdirSync(screenshotDir)
                .filter(file => file.includes('Cluster') && file.endsWith('.png'));

                // Attach each screenshot to the report
                for (const screenshot of screenshots) {
                const screenshotPath = screenshotDir + screenshot;
                const image = fs.readFileSync(screenshotPath);

                // Attach the screenshot with a descriptive name
                await this.world.attach(image, 'image/png');
                console.log(`Attached screenshot: ${screenshot}`);
                }
    
            }
}

module.exports = ScreenshotUtility;
