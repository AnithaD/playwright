const {After, Before, AfterStep,setDefaultTimeout, BeforeAll} = require('@cucumber/cucumber');
const {chromium} = require('@playwright/test');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const screenshotUtility = require('../utility/ScreenshotUtility');


//convert Folder to Zip File 
const zipFolder = async (sourceFolder, outputZipFile) => {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputZipFile);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve(outputZipFile));
    archive.on('error', (err) => reject(err));

    archive.pipe(output);
    archive.directory(sourceFolder, false);
    archive.finalize();
  });
};
const cleanDirectory = (dirPath) => {
  if (fs.existsSync(dirPath)) {
    fs.readdirSync(dirPath).forEach((file) => {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isFile()) {
        fs.unlinkSync(filePath);
      } else if (fs.lstatSync(filePath).isDirectory()) {
        cleanDirectory(filePath);
      }
    });
    console.log(`Directory cleaned: ${dirPath}`);
  }
};

const ensureDirectoryExists = (dirPath) => {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`Directory created: ${dirPath}`);
  }
};

// Hook
BeforeAll(() => {
  const screenshotDir = path.resolve('screenshots');
  try {
    cleanDirectory(screenshotDir);
    ensureDirectoryExists(screenshotDir);
  } catch (err) {
    console.error(`Error cleaning or creating directory ${screenshotDir}:`, err.message);
  }
});

// Before hook to initialize the browser and page from world.js file
Before(async function () {
  await this.initialize();
  setDefaultTimeout(60000);
});

// AfterStep hook to take screenshot for failed steps
AfterStep(async function (step) {
  if (step.result.status === 'PASSED' | 'FAILED') {
    // Create screenshots folder if it doesn't exist
    const screenshotDir = path.resolve('screenshots');
    if (!fs.existsSync(screenshotDir)) {
      fs.mkdirSync(screenshotDir);
    }
    // Generate screenshot file path with timestamp
    const screenshotPath = path.join(screenshotDir, `screenshot-${Date.now()}.png`);

    // Take screenshot of the page on failure
    await this.page.screenshot({ path: screenshotPath });
  }

  
});

// Before hook to close the browser from world.js file
After(async function () {

  const screenshotDir = path.resolve('screenshots');
  const outputZipFile = path.resolve('screenshots.zip');

  if (fs.existsSync(screenshotDir)) {
    try {
      await zipFolder(screenshotDir, outputZipFile);
      console.log(`Screenshots archived: ${outputZipFile}`);

      // Attach ZIP file to the report
      const zipData = fs.readFileSync(outputZipFile);
      const screenshot_Utility = new screenshotUtility(this); 
      screenshot_Utility.world.attach(zipData, 'application/zip');
    } catch (err) {
      console.error(`Error creating ZIP archive: ${err.message}`);
    }
  }
  await this.closeApplication();
});

 
/*const logStream = fs.createWriteStream('test.log', { flags: 'a' });
//tracking records using logs in the report 
const log = (message) => {
  const timestamp = new Date().toISOString();
  logStream.write(`[${timestamp}] ${message}\n`);
};*/

 
 