const { setWorldConstructor } = require('@cucumber/cucumber');
const {chromium} = require('@playwright/test');
const { exec , env} = require('child_process');
const config = require('../utility/config');
const electron = require('electron');

class CustomWorld {
    constructor({ attach, log, link, parameters }) {
        this.attach = attach;
        this.log = log;
        this.link = link;
        this.parameters = parameters;

        this.browser = null;
        this.context = null;
        this.page = null;
        this.data = {}; // A shared object for storing runtime data
    }

    setProperty(key, value) {
    this.data[key] = value;
    }
        
    getProperty(key) {
    return this.data[key];
    }

    async initialize() {
        const appType = process.env.APPLICATION_TYPE ; 
        this.applicationType = appType;

        if (appType === 'web') {
            if(config.browser === 'chrome'){
            this.browser = await chromium.launch({ headless: false });
            this.context = await this.browser.newContext();
            this.page = await this.context.newPage();
        }
        } else if (appType === 'desktop') {
            // Example: Launching a desktop application (adjust to your app's requirements)
            const electronApp = await electron.launch({ 
                executablePath: '/path/to/your/electron-app/executable', // Path to your Electron app
              });         
            
        } else {
            throw new Error(`Unsupported application type: ${appType}`);
        }
    }

    

    async closeApplication() {
        if (this.applicationType === 'web') {
            await this.browser.close();
        } else if (this.applicationType === 'desktop') {
            this.desktopAppProcess.kill(); // Terminate the desktop app process
        }
    }

    }

setWorldConstructor(CustomWorld);
