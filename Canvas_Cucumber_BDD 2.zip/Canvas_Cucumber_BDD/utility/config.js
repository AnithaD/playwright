const config = {
    baseURL: 'https://openlayers.org/en/latest/examples/clusters-dynamic.html',
    timeout: 5000,
    browser: 'chrome',
    /*apiEndpoints: {
      login: '/api/v1/login',
      register: '/api/v1/register',
    },*/
  };
  
  module.exports = config;
  