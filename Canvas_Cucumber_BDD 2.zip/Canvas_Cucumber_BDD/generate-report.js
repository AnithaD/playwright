const report = require('multiple-cucumber-html-reporter');

report.generate({
  jsonDir: './reports', // Directory containing cucumber JSON report(s)
  reportPath: './reports/html-report', // Output directory for the HTML report
  metadata: {
    browser: {
      name: 'chrome',
      version: '112',
    },
    device: 'Local Test Machine',
    platform: {
      name: 'windows',
      version: '10',
    },
  },
  customData: {
    title: 'Run Info',
    data: [
      { label: 'Project', value: 'Minestar Project' },
      { label: 'Release', value: '1.0.0' },
      { label: 'Execution Start Time', value: new Date().toLocaleString() },
      { label: 'Execution End Time', value: new Date().toLocaleString() },
    ],
  },
});
